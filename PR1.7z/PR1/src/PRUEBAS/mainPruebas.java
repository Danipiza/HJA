package PRUEBAS;

public class mainPruebas {

	static String entrada = "AhAcQhJhTh";
	
	
	public static void main(String[] args) {
		
		// METODOS
		
		// COLOR
		char[] entradaChar = entrada.toCharArray();		
		int cont1 = 1, cont2 = 0;	
		char contC1 = entradaChar[1], contC2 = ' ';
		
		int i = 0, j = 3;
		boolean fin = false;		
		while(i != 5 && !fin) { 
			// RECORRE LA LISTA, 2 CONTADORES PARA SABER SI HAY COLOR O PUEDE HABER
			if(entradaChar[j] == contC1) ++cont1;
			else if(cont2 == 0) contC2 = entradaChar[j];
			else if(contC2 == entradaChar[j]) ++cont2;
			else if(cont1 == cont2 && cont1== 2) fin = true;
			else fin = true;			
			j+=2;
			++i;
		}
		// ESCALERA 
		/*while(i != 5) {
			
			while ((carta[i].elem == carta[i+1].elem + 1  && i < list.size() - 1) ||
					(carta[i].elem == carta[i+1].elem + 2 ))		
				if(carta[i].elem == carta[i+1].elem + 1  && i < list.size() - 1)) draw = false;
			}
		}*/
			// REAL, COLOR
		
		// POKER PAREJAS TRIOS		
			// FULL HOUSE
		

	}

	

}
