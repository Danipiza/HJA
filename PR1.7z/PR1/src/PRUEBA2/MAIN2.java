package PRUEBA2;

public class MAIN2 {

	public static void main(String[] args) {
		System.out.println("hola");

	}

}
